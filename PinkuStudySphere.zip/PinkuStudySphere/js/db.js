/* =========================================================
   PinkuStudySphere — db.js
   Local-storage backed "database" + seed data
   ========================================================= */

const DB_KEYS = {
  users: 'pss_users',
  session: 'pss_session',
  courses: 'pss_courses',
  enrollments: 'pss_enrollments',
  notifications: 'pss_notifications',
  resetTokens: 'pss_reset_tokens',
  seeded: 'pss_seeded_v1'
};

function pssUid(prefix){
  return (prefix||'id') + '_' + Date.now().toString(36) + Math.random().toString(36).slice(2,8);
}

function pssRead(key){
  try{
    const raw = localStorage.getItem(key);
    return raw ? JSON.parse(raw) : null;
  }catch(e){ console.error('DB read error', key, e); return null; }
}
function pssWrite(key, value){
  localStorage.setItem(key, JSON.stringify(value));
}

/* Very lightweight hash so we don't store plaintext passwords verbatim.
   NOT for real security — this is a client-only demo project. */
function pssHash(str){
  let h = 0;
  for(let i=0;i<str.length;i++){ h = (Math.imul(31,h) + str.charCodeAt(i))|0; }
  return 'h' + Math.abs(h).toString(36);
}

function pssSeedIfNeeded(){
  if(pssRead(DB_KEYS.seeded)) return;

  const now = Date.now();

  const users = [
    {
      id: 'u_admin', name: 'Priya Admin', email: 'admin@pinkustudysphere.com',
      password: pssHash('Admin@123'), role: 'admin', createdAt: now,
      avatarColor: '#C93F7A'
    },
    {
      id: 'u_student', name: 'Aditi Sharma', email: 'student@pinkustudysphere.com',
      password: pssHash('Student@123'), role: 'student', createdAt: now,
      avatarColor: '#3E9C82'
    }
  ];

  const courses = [
    {
      id: 'c_webdev', title: 'Full-Stack Web Development Bootcamp',
      category: 'Web Development', instructor: 'Rhea Kapoor', level: 'Beginner',
      price: 1499, thumbIcon: '💻', thumbColor: 'linear-gradient(135deg,#FF6FA3,#C93F7A)',
      description: 'Go from zero to deploying real websites. Learn HTML, CSS, JavaScript, and how to structure a modern front-end project, with hands-on projects at every stage.',
      modules: [
        { id:'m1', title:'Foundations of the Web', lessons:[
          { id:'l1', title:'How the Web Works', duration:'08:12', type:'video' },
          { id:'l2', title:'Setting Up Your Dev Environment', duration:'06:40', type:'video' },
          { id:'l3', title:'HTML Structure & Semantics', duration:'12:05', type:'video' }
        ]},
        { id:'m2', title:'Styling with CSS', lessons:[
          { id:'l4', title:'Box Model & Layout', duration:'10:30', type:'video' },
          { id:'l5', title:'Flexbox in Practice', duration:'14:22', type:'video' },
          { id:'l6', title:'Responsive Design Reading', duration:'6 min read', type:'reading' }
        ]},
        { id:'m3', title:'JavaScript Essentials', lessons:[
          { id:'l7', title:'Variables & Functions', duration:'11:15', type:'video' },
          { id:'l8', title:'DOM Manipulation', duration:'13:48', type:'video' }
        ]}
      ],
      materials: [
        { id:'mt1', name:'Course Syllabus.pdf', type:'PDF', size:'240 KB' },
        { id:'mt2', name:'HTML Cheat Sheet.pdf', type:'PDF', size:'180 KB' },
        { id:'mt3', name:'Starter Code.zip', type:'ZIP', size:'1.1 MB' }
      ],
      createdAt: now
    },
    {
      id: 'c_uiux', title: 'UI/UX Design for Beginners',
      category: 'Design', instructor: 'Kabir Mehta', level: 'Beginner',
      price: 999, thumbIcon: '🎨', thumbColor: 'linear-gradient(135deg,#F4B860,#C93F7A)',
      description: 'Learn the principles of user-centred design, wireframing, and prototyping. Build a polished portfolio case study by the end of the course.',
      modules: [
        { id:'m1', title:'Design Thinking', lessons:[
          { id:'l1', title:'What is UX?', duration:'07:50', type:'video' },
          { id:'l2', title:'User Research Basics', duration:'09:12', type:'video' }
        ]},
        { id:'m2', title:'Wireframing & Prototyping', lessons:[
          { id:'l3', title:'Low-Fidelity Wireframes', duration:'10:05', type:'video' },
          { id:'l4', title:'Prototyping Tools Overview', duration:'5 min read', type:'reading' }
        ]}
      ],
      materials: [
        { id:'mt1', name:'Wireframe Templates.zip', type:'ZIP', size:'860 KB' },
        { id:'mt2', name:'Design Checklist.pdf', type:'PDF', size:'120 KB' }
      ],
      createdAt: now
    },
    {
      id: 'c_python', title: 'Python for Data Analysis',
      category: 'Data Science', instructor: 'Ananya Rao', level: 'Intermediate',
      price: 1299, thumbIcon: '📊', thumbColor: 'linear-gradient(135deg,#6FB3E0,#3E9C82)',
      description: 'Master Python fundamentals and use Pandas, NumPy, and Matplotlib to clean, analyse, and visualise real-world datasets.',
      modules: [
        { id:'m1', title:'Python Basics', lessons:[
          { id:'l1', title:'Syntax & Data Types', duration:'09:40', type:'video' },
          { id:'l2', title:'Loops & Functions', duration:'11:02', type:'video' }
        ]},
        { id:'m2', title:'Working with Data', lessons:[
          { id:'l3', title:'Intro to Pandas', duration:'15:30', type:'video' },
          { id:'l4', title:'Data Visualisation', duration:'12:18', type:'video' }
        ]}
      ],
      materials: [
        { id:'mt1', name:'Dataset Pack.zip', type:'ZIP', size:'2.3 MB' },
        { id:'mt2', name:'Pandas Reference.pdf', type:'PDF', size:'310 KB' }
      ],
      createdAt: now
    },
    {
      id: 'c_marketing', title: 'Digital Marketing Fundamentals',
      category: 'Marketing', instructor: 'Neha Joshi', level: 'Beginner',
      price: 799, thumbIcon: '📣', thumbColor: 'linear-gradient(135deg,#7FCFB4,#6FB3E0)',
      description: 'Understand SEO, social media, and email marketing strategies to grow an audience and measure real results.',
      modules: [
        { id:'m1', title:'Marketing Foundations', lessons:[
          { id:'l1', title:'The Marketing Funnel', duration:'08:20', type:'video' },
          { id:'l2', title:'Know Your Audience', duration:'07:44', type:'video' }
        ]},
        { id:'m2', title:'Channels & Tactics', lessons:[
          { id:'l3', title:'SEO Basics', duration:'10:55', type:'video' },
          { id:'l4', title:'Email Campaigns Reading', duration:'4 min read', type:'reading' }
        ]}
      ],
      materials: [
        { id:'mt1', name:'Campaign Planner.pdf', type:'PDF', size:'150 KB' }
      ],
      createdAt: now
    },
    {
      id: 'c_photo', title: 'Photography Basics: Shoot Like a Pro',
      category: 'Photography', instructor: 'Vikram Nair', level: 'Beginner',
      price: 699, thumbIcon: '📷', thumbColor: 'linear-gradient(135deg,#C93F7A,#3B2545)',
      description: 'Understand your camera, composition, and lighting to take striking photos with any equipment you already own.',
      modules: [
        { id:'m1', title:'Camera Basics', lessons:[
          { id:'l1', title:'Aperture, Shutter, ISO', duration:'09:05', type:'video' },
          { id:'l2', title:'Composition Rules', duration:'08:33', type:'video' }
        ]}
      ],
      materials: [
        { id:'mt1', name:'Settings Cheat Sheet.pdf', type:'PDF', size:'95 KB' }
      ],
      createdAt: now
    },
    {
      id: 'c_business', title: 'Business Communication Mastery',
      category: 'Business', instructor: 'Sanjana Iyer', level: 'Intermediate',
      price: 899, thumbIcon: '💼', thumbColor: 'linear-gradient(135deg,#F4B860,#7FCFB4)',
      description: 'Write clearer emails, run better meetings, and present with confidence — practical skills for any workplace.',
      modules: [
        { id:'m1', title:'Written Communication', lessons:[
          { id:'l1', title:'Writing Clear Emails', duration:'07:15', type:'video' },
          { id:'l2', title:'Reports & Summaries', duration:'6 min read', type:'reading' }
        ]},
        { id:'m2', title:'Verbal Communication', lessons:[
          { id:'l3', title:'Running Effective Meetings', duration:'09:48', type:'video' }
        ]}
      ],
      materials: [
        { id:'mt1', name:'Email Templates.zip', type:'ZIP', size:'210 KB' }
      ],
      createdAt: now
    }
  ];

  const enrollments = [
    { id: pssUid('en'), userId:'u_student', courseId:'c_webdev', enrolledAt: now - 6*86400000,
      completedLessonIds:['l1','l2','l3','l4'], completed:false, certificateIssued:false },
    { id: pssUid('en'), userId:'u_student', courseId:'c_uiux', enrolledAt: now - 2*86400000,
      completedLessonIds:['l1','l2','l3','l4'], completed:true, certificateIssued:true, completedAt: now - 86400000 }
  ];

  const notifications = [
    { id: pssUid('nt'), userId:'u_student', type:'welcome', message:'Welcome to PinkuStudySphere! Start your first course today.', date: now - 6*86400000, read:true },
    { id: pssUid('nt'), userId:'u_student', type:'progress', message:'You completed "UI/UX Design for Beginners" — certificate ready!', date: now - 86400000, read:false },
    { id: pssUid('nt'), userId:'u_student', type:'reminder', message:'You are 3 lessons away from finishing "Full-Stack Web Development Bootcamp".', date: now - 3600000, read:false },
    { id: pssUid('nt'), userId:'u_admin', type:'system', message:'2 students enrolled in your courses this week.', date: now - 7200000, read:false }
  ];

  pssWrite(DB_KEYS.users, users);
  pssWrite(DB_KEYS.courses, courses);
  pssWrite(DB_KEYS.enrollments, enrollments);
  pssWrite(DB_KEYS.notifications, notifications);
  pssWrite(DB_KEYS.resetTokens, []);
  pssWrite(DB_KEYS.seeded, true);
}

pssSeedIfNeeded();

/* ---------- Users ---------- */
const DB = {
  getUsers(){ return pssRead(DB_KEYS.users) || []; },
  saveUsers(u){ pssWrite(DB_KEYS.users, u); },
  findUserByEmail(email){
    return this.getUsers().find(u => u.email.toLowerCase() === String(email).toLowerCase());
  },
  findUserById(id){ return this.getUsers().find(u => u.id === id); },

  /* ---------- Session ---------- */
  getSession(){ return pssRead(DB_KEYS.session); },
  setSession(userId){ pssWrite(DB_KEYS.session, { userId, since: Date.now() }); },
  clearSession(){ localStorage.removeItem(DB_KEYS.session); },
  currentUser(){
    const s = this.getSession();
    if(!s) return null;
    return this.findUserById(s.userId) || null;
  },

  /* ---------- Courses ---------- */
  getCourses(){ return pssRead(DB_KEYS.courses) || []; },
  saveCourses(c){ pssWrite(DB_KEYS.courses, c); },
  findCourse(id){ return this.getCourses().find(c => c.id === id); },
  deleteCourse(id){
    this.saveCourses(this.getCourses().filter(c => c.id !== id));
  },

  /* ---------- Enrollments ---------- */
  getEnrollments(){ return pssRead(DB_KEYS.enrollments) || []; },
  saveEnrollments(e){ pssWrite(DB_KEYS.enrollments, e); },
  enrollmentsForUser(userId){ return this.getEnrollments().filter(e => e.userId === userId); },
  findEnrollment(userId, courseId){
    return this.getEnrollments().find(e => e.userId===userId && e.courseId===courseId);
  },
  isEnrolled(userId, courseId){ return !!this.findEnrollment(userId, courseId); },

  /* ---------- Notifications ---------- */
  getNotifications(){ return pssRead(DB_KEYS.notifications) || []; },
  saveNotifications(n){ pssWrite(DB_KEYS.notifications, n); },
  notificationsForUser(userId){
    return this.getNotifications().filter(n => n.userId === userId).sort((a,b)=>b.date-a.date);
  },
  unreadCount(userId){
    return this.notificationsForUser(userId).filter(n => !n.read).length;
  },
  addNotification(userId, message, type){
    const all = this.getNotifications();
    all.push({ id: pssUid('nt'), userId, message, type: type||'system', date: Date.now(), read:false });
    this.saveNotifications(all);
  },

  /* ---------- Reset tokens ---------- */
  getResetTokens(){ return pssRead(DB_KEYS.resetTokens) || []; },
  saveResetTokens(t){ pssWrite(DB_KEYS.resetTokens, t); }
};

function pssTotalLessons(course){
  return course.modules.reduce((sum,m)=>sum+m.lessons.length, 0);
}
function pssProgressPercent(userId, course){
  const en = DB.findEnrollment(userId, course.id);
  if(!en) return 0;
  const total = pssTotalLessons(course);
  if(total===0) return 0;
  return Math.round((en.completedLessonIds.length/total)*100);
}
