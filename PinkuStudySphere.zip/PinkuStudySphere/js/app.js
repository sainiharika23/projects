/* =========================================================
   PinkuStudySphere — app.js
   Navbar rendering, auth guards, toasts, shared utilities
   ========================================================= */

function pssFormatDate(ts){
  const d = new Date(ts);
  return d.toLocaleDateString('en-IN', { day:'2-digit', month:'short', year:'numeric' });
}
function pssFormatMoney(n){
  return '₹' + Number(n).toLocaleString('en-IN');
}
function pssInitials(name){
  return name.split(' ').map(p=>p[0]).slice(0,2).join('').toUpperCase();
}
function pssQuery(name){
  return new URLSearchParams(window.location.search).get(name);
}
function pssEscapeHtml(str){
  const div = document.createElement('div');
  div.textContent = str;
  return div.innerHTML;
}

function pssToast(message, type){
  let wrap = document.querySelector('.toast-wrap');
  if(!wrap){
    wrap = document.createElement('div');
    wrap.className = 'toast-wrap';
    document.body.appendChild(wrap);
  }
  const t = document.createElement('div');
  t.className = 'toast ' + (type||'success');
  t.textContent = message;
  wrap.appendChild(t);
  setTimeout(()=>{ t.style.opacity='0'; t.style.transition='opacity .3s'; setTimeout(()=>t.remove(),300); }, 3200);
}

/* Redirect helpers used at top of protected pages */
function pssRequireAuth(){
  const user = DB.currentUser();
  if(!user){
    window.location.href = 'login.html';
    return null;
  }
  return user;
}
function pssRequireAdmin(){
  const user = pssRequireAuth();
  if(user && user.role !== 'admin'){
    window.location.href = 'student-dashboard.html';
    return null;
  }
  return user;
}
function pssRedirectIfLoggedIn(){
  const user = DB.currentUser();
  if(user){
    window.location.href = user.role === 'admin' ? 'admin-dashboard.html' : 'student-dashboard.html';
  }
}

/* =========================================================
   Navbar
   ========================================================= */
function pssRenderNavbar(activePage){
  const mount = document.getElementById('site-header');
  if(!mount) return;
  const user = DB.currentUser();

  const guestLinks = `
    <a href="index.html" class="${activePage==='home'?'active':''}">Home</a>
    <a href="browse-courses.html" class="${activePage==='browse'?'active':''}">Courses</a>
  `;

  const studentLinks = `
    <a href="student-dashboard.html" class="${activePage==='student-dashboard'?'active':''}">Dashboard</a>
    <a href="browse-courses.html" class="${activePage==='browse'?'active':''}">Browse</a>
    <a href="my-courses.html" class="${activePage==='my-courses'?'active':''}">My Courses</a>
    <a href="progress.html" class="${activePage==='progress'?'active':''}">Progress</a>
  `;

  const adminLinks = `
    <a href="admin-dashboard.html" class="${activePage==='admin-dashboard'?'active':''}">Dashboard</a>
    <a href="courses.html" class="${activePage==='manage-courses'?'active':''}">Manage Courses</a>
    <a href="browse-courses.html" class="${activePage==='browse'?'active':''}">Browse</a>
  `;

  let navLinks = guestLinks;
  if(user && user.role === 'student') navLinks = studentLinks;
  if(user && user.role === 'admin') navLinks = adminLinks;

  let rightSide = `
    <a href="login.html" class="btn btn-secondary btn-sm">Log In</a>
    <a href="register.html" class="btn btn-primary btn-sm">Sign Up</a>
  `;

  if(user){
    const unread = DB.unreadCount(user.id);
    rightSide = `
      <a href="notifications.html" class="icon-btn" title="Notifications" aria-label="Notifications">
        🔔
        ${unread>0 ? `<span class="badge-count">${unread>9?'9+':unread}</span>` : ''}
      </a>
      <div class="avatar-chip" id="pss-user-menu-btn">
        <span class="avatar-circle">${pssInitials(user.name)}</span>
        <span>${user.name.split(' ')[0]}</span>
        <span style="opacity:.5">▾</span>
      </div>
    `;
  }

  mount.innerHTML = `
    <header class="site-header">
      <nav class="navbar">
        <a href="${user ? (user.role==='admin'?'admin-dashboard.html':'student-dashboard.html') : 'index.html'}" class="brand" style="text-decoration:none;">
          <span class="brand-badge">P</span>
          Pinku<span class="dot">Study</span>Sphere
        </a>
        <ul class="nav-links">${navLinks}</ul>
        <div class="nav-actions" style="position:relative;">
          ${rightSide}
          ${user ? `
          <div id="pss-user-dropdown" class="card" style="display:none; position:absolute; right:0; top:48px; min-width:180px; padding:8px; z-index:60;">
            <div style="padding:8px 10px; font-size:.8rem; color:var(--ink-soft); border-bottom:1px solid var(--line); margin-bottom:6px;">
              Signed in as<br><strong style="color:var(--ink)">${pssEscapeHtml(user.email)}</strong>
            </div>
            <a href="${user.role==='admin'?'admin-dashboard.html':'student-dashboard.html'}" style="display:block;padding:8px 10px;border-radius:8px;color:var(--ink);font-weight:600;font-size:.9rem;">Dashboard</a>
            <a href="#" id="pss-logout-btn" style="display:block;padding:8px 10px;border-radius:8px;color:var(--danger);font-weight:600;font-size:.9rem;">Log Out</a>
          </div>` : ''}
        </div>
      </nav>
    </header>
  `;

  const menuBtn = document.getElementById('pss-user-menu-btn');
  const dropdown = document.getElementById('pss-user-dropdown');
  if(menuBtn && dropdown){
    menuBtn.addEventListener('click', (e)=>{
      e.stopPropagation();
      dropdown.style.display = dropdown.style.display === 'none' ? 'block' : 'none';
    });
    document.addEventListener('click', ()=>{ dropdown.style.display = 'none'; });
  }
  const logoutBtn = document.getElementById('pss-logout-btn');
  if(logoutBtn){
    logoutBtn.addEventListener('click', (e)=>{
      e.preventDefault();
      DB.clearSession();
      window.location.href = 'index.html';
    });
  }
}

function pssRenderFooter(){
  const mount = document.getElementById('site-footer');
  if(!mount) return;
  mount.innerHTML = `
    <footer class="site-footer">
      <div class="container">
        <strong style="font-family:var(--font-display); color:var(--ink);">PinkuStudySphere</strong>
        &nbsp;·&nbsp; Learn something new every day.
        &nbsp;·&nbsp; © ${new Date().getFullYear()} All rights reserved.
      </div>
    </footer>
  `;
}

document.addEventListener('DOMContentLoaded', ()=>{
  const page = document.body.getAttribute('data-page') || '';
  pssRenderNavbar(page);
  pssRenderFooter();
});
