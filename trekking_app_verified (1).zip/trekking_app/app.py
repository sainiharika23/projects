import os
from datetime import datetime, date
from functools import wraps

from flask import Flask, render_template, redirect, url_for, request, flash, abort
from flask_login import (
    LoginManager, login_user, logout_user, login_required, current_user
)

from models import db, User, Trek, Booking

BASE_DIR = os.path.abspath(os.path.dirname(__file__))
DB_PATH = os.path.join(BASE_DIR, "trekking.db")

ADMIN_EMAIL = "admin@trek.com"
ADMIN_PASSWORD = "admin123"

DIFFICULTIES = ["Easy", "Moderate", "Hard"]
TREK_STATUSES = ["Pending", "Approved", "Open", "Closed", "Completed"]


def create_app():
    app = Flask(__name__)
    app.config["SECRET_KEY"] = "dev-secret-key-change-in-production"
    app.config["SQLALCHEMY_DATABASE_URI"] = f"sqlite:///{DB_PATH}"
    app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False

    db.init_app(app)

    login_manager = LoginManager()
    login_manager.login_view = "login"
    login_manager.login_message = "Please log in to access this page."
    login_manager.init_app(app)

    @login_manager.user_loader
    def load_user(user_id):
        return db.session.get(User, int(user_id))

    register_routes(app)

    with app.app_context():
        db.create_all()
        seed_admin()

    return app


def seed_admin():
    """Programmatically create the pre-existing Admin superuser if it doesn't exist."""
    admin = User.query.filter_by(email=ADMIN_EMAIL).first()
    if not admin:
        admin = User(
            name="System Admin",
            email=ADMIN_EMAIL,
            role="admin",
            approved=True,
            blacklisted=False,
        )
        admin.set_password(ADMIN_PASSWORD)
        db.session.add(admin)
        db.session.commit()


# ---------------------------------------------------------------------------
# Access-control decorators
# ---------------------------------------------------------------------------

def role_required(*roles):
    def decorator(f):
        @wraps(f)
        @login_required
        def wrapped(*args, **kwargs):
            if current_user.role not in roles:
                abort(403)
            return f(*args, **kwargs)
        return wrapped
    return decorator


def staff_active_required(f):
    """Staff must be approved by admin and not blacklisted to reach their dashboard."""
    @wraps(f)
    @role_required("staff")
    def wrapped(*args, **kwargs):
        if current_user.blacklisted:
            flash("Your staff account has been blacklisted by the admin.", "danger")
            return redirect(url_for("logout"))
        if not current_user.approved:
            return render_template("pending.html")
        return f(*args, **kwargs)
    return wrapped


def trekker_active_required(f):
    @wraps(f)
    @role_required("trekker")
    def wrapped(*args, **kwargs):
        if current_user.blacklisted:
            flash("Your account has been blacklisted by the admin.", "danger")
            return redirect(url_for("logout"))
        return f(*args, **kwargs)
    return wrapped


def parse_date(value):
    return datetime.strptime(value, "%Y-%m-%d").date()


# ---------------------------------------------------------------------------
# Routes
# ---------------------------------------------------------------------------

def register_routes(app):

    @app.route("/")
    def index():
        if current_user.is_authenticated:
            return redirect(role_home())
        return redirect(url_for("login"))

    # ---------------- Auth ----------------

    @app.route("/register", methods=["GET", "POST"])
    def register():
        if request.method == "POST":
            name = request.form.get("name", "").strip()
            email = request.form.get("email", "").strip().lower()
            password = request.form.get("password", "")
            contact = request.form.get("contact", "").strip()
            role = request.form.get("role")

            if role not in ("staff", "trekker"):
                flash("Invalid role selected.", "danger")
                return redirect(url_for("register"))

            if not name or not email or not password:
                flash("Name, email and password are required.", "danger")
                return redirect(url_for("register"))

            if User.query.filter_by(email=email).first():
                flash("An account with that email already exists.", "danger")
                return redirect(url_for("register"))

            user = User(
                name=name,
                email=email,
                contact=contact,
                role=role,
                approved=(role == "trekker"),  # trekkers don't need approval; staff do
                blacklisted=False,
            )
            user.set_password(password)
            db.session.add(user)
            db.session.commit()

            if role == "staff":
                flash("Registration successful. Please wait for admin approval before logging in to your dashboard.", "success")
            else:
                flash("Registration successful. You can now log in.", "success")
            return redirect(url_for("login"))

        return render_template("register.html")

    @app.route("/login", methods=["GET", "POST"])
    def login():
        if current_user.is_authenticated:
            return redirect(role_home())

        if request.method == "POST":
            email = request.form.get("email", "").strip().lower()
            password = request.form.get("password", "")
            user = User.query.filter_by(email=email).first()

            if user is None or not user.check_password(password):
                flash("Invalid email or password.", "danger")
                return redirect(url_for("login"))

            if user.blacklisted:
                flash("This account has been blacklisted. Contact the admin.", "danger")
                return redirect(url_for("login"))

            login_user(user)
            return redirect(role_home())

        return render_template("login.html")

    @app.route("/logout")
    @login_required
    def logout():
        logout_user()
        flash("You have been logged out.", "info")
        return redirect(url_for("login"))

    def role_home():
        if current_user.role == "admin":
            return url_for("admin_dashboard")
        if current_user.role == "staff":
            return url_for("staff_dashboard")
        return url_for("user_dashboard")

    # ---------------- Admin ----------------

    @app.route("/admin/dashboard")
    @role_required("admin")
    def admin_dashboard():
        stats = {
            "total_treks": Trek.query.count(),
            "total_users": User.query.filter_by(role="trekker").count(),
            "total_staff": User.query.filter_by(role="staff").count(),
            "total_bookings": Booking.query.count(),
            "pending_staff": User.query.filter_by(role="staff", approved=False, blacklisted=False).count(),
        }
        return render_template("admin_dashboard.html", stats=stats)

    @app.route("/admin/treks")
    @role_required("admin")
    def admin_treks():
        q = request.args.get("q", "").strip()
        query = Trek.query
        if q:
            like = f"%{q}%"
            query = query.filter(db.or_(Trek.name.ilike(like), Trek.location.ilike(like)))
        treks = query.order_by(Trek.id.desc()).all()
        staff_options = User.query.filter_by(role="staff", approved=True, blacklisted=False).order_by(User.name).all()
        return render_template("admin_treks.html", treks=treks, q=q, staff_options=staff_options)

    @app.route("/admin/treks/new", methods=["GET", "POST"])
    @role_required("admin")
    def admin_trek_new():
        if request.method == "POST":
            trek = Trek(
                name=request.form["name"].strip(),
                location=request.form["location"].strip(),
                difficulty=request.form["difficulty"],
                duration_days=int(request.form["duration_days"]),
                total_slots=int(request.form["total_slots"]),
                available_slots=int(request.form["total_slots"]),
                description=request.form.get("description", "").strip(),
                status="Pending",
                start_date=parse_date(request.form["start_date"]),
                end_date=parse_date(request.form["end_date"]),
            )
            db.session.add(trek)
            db.session.commit()
            flash("Trek created.", "success")
            return redirect(url_for("admin_treks"))
        return render_template("admin_trek_form.html", trek=None, difficulties=DIFFICULTIES)

    @app.route("/admin/treks/<int:trek_id>/edit", methods=["GET", "POST"])
    @role_required("admin")
    def admin_trek_edit(trek_id):
        trek = Trek.query.get_or_404(trek_id)
        if request.method == "POST":
            booked_count = trek.total_slots - trek.available_slots
            trek.name = request.form["name"].strip()
            trek.location = request.form["location"].strip()
            trek.difficulty = request.form["difficulty"]
            trek.duration_days = int(request.form["duration_days"])
            new_total = int(request.form["total_slots"])
            trek.total_slots = new_total
            trek.available_slots = max(new_total - booked_count, 0)
            trek.description = request.form.get("description", "").strip()
            trek.start_date = parse_date(request.form["start_date"])
            trek.end_date = parse_date(request.form["end_date"])
            db.session.commit()
            flash("Trek updated.", "success")
            return redirect(url_for("admin_treks"))
        return render_template("admin_trek_form.html", trek=trek, difficulties=DIFFICULTIES)

    @app.route("/admin/treks/<int:trek_id>/delete", methods=["POST"])
    @role_required("admin")
    def admin_trek_delete(trek_id):
        trek = Trek.query.get_or_404(trek_id)
        db.session.delete(trek)
        db.session.commit()
        flash("Trek deleted.", "info")
        return redirect(url_for("admin_treks"))

    @app.route("/admin/treks/<int:trek_id>/assign", methods=["POST"])
    @role_required("admin")
    def admin_trek_assign(trek_id):
        trek = Trek.query.get_or_404(trek_id)
        staff_id = request.form.get("staff_id")
        trek.assigned_staff_id = int(staff_id) if staff_id else None
        if trek.assigned_staff_id and trek.status == "Pending":
            trek.status = "Approved"
        db.session.commit()
        flash("Staff assignment updated.", "success")
        return redirect(url_for("admin_treks"))

    @app.route("/admin/staff")
    @role_required("admin")
    def admin_staff():
        q = request.args.get("q", "").strip()
        query = User.query.filter_by(role="staff")
        if q:
            like = f"%{q}%"
            query = query.filter(db.or_(User.name.ilike(like), User.email.ilike(like)))
        staff_list = query.order_by(User.id.desc()).all()
        return render_template("admin_staff.html", staff_list=staff_list, q=q)

    @app.route("/admin/staff/<int:user_id>/approve", methods=["POST"])
    @role_required("admin")
    def admin_staff_approve(user_id):
        staff = User.query.filter_by(id=user_id, role="staff").first_or_404()
        staff.approved = True
        db.session.commit()
        flash(f"{staff.name} approved.", "success")
        return redirect(url_for("admin_staff"))

    @app.route("/admin/users")
    @role_required("admin")
    def admin_users():
        q = request.args.get("q", "").strip()
        query = User.query.filter_by(role="trekker")
        if q:
            like = f"%{q}%"
            query = query.filter(db.or_(User.name.ilike(like), User.email.ilike(like)))
        users_list = query.order_by(User.id.desc()).all()
        return render_template("admin_users.html", users_list=users_list, q=q)

    @app.route("/admin/blacklist/<int:user_id>", methods=["POST"])
    @role_required("admin")
    def admin_toggle_blacklist(user_id):
        user = User.query.get_or_404(user_id)
        if user.role == "admin":
            abort(403)
        user.blacklisted = not user.blacklisted
        db.session.commit()
        state = "blacklisted" if user.blacklisted else "reinstated"
        flash(f"{user.name} has been {state}.", "warning")
        return redirect(request.referrer or url_for("admin_dashboard"))

    @app.route("/admin/bookings")
    @role_required("admin")
    def admin_bookings():
        bookings = Booking.query.order_by(Booking.id.desc()).all()
        return render_template("admin_bookings.html", bookings=bookings)

    @app.route("/admin/profile", methods=["GET", "POST"])
    @role_required("admin")
    def admin_profile():
        if request.method == "POST":
            current_user.name = request.form["name"].strip()
            current_user.contact = request.form.get("contact", "").strip()
            new_password = request.form.get("password", "")
            if new_password:
                current_user.set_password(new_password)
            db.session.commit()
            flash("Profile updated.", "success")
            return redirect(url_for("admin_profile"))
        return render_template("admin_profile.html")

    # ---------------- Staff ----------------

    @app.route("/staff/dashboard")
    @staff_active_required
    def staff_dashboard():
        treks = Trek.query.filter_by(assigned_staff_id=current_user.id).order_by(Trek.id.desc()).all()
        counts = {t.id: Booking.query.filter_by(trek_id=t.id, status="Booked").count() for t in treks}
        return render_template("staff_dashboard.html", treks=treks, counts=counts)

    @app.route("/staff/treks/<int:trek_id>/update", methods=["GET", "POST"])
    @staff_active_required
    def staff_trek_update(trek_id):
        trek = Trek.query.filter_by(id=trek_id, assigned_staff_id=current_user.id).first_or_404()
        if request.method == "POST":
            action = request.form.get("action")
            if action == "update_slots":
                booked_count = trek.total_slots - trek.available_slots
                new_total = int(request.form["total_slots"])
                trek.total_slots = new_total
                trek.available_slots = max(new_total - booked_count, 0)
                flash("Slots updated.", "success")
            elif action == "set_status":
                new_status = request.form.get("status")
                if new_status in TREK_STATUSES:
                    trek.status = new_status
                    flash(f"Trek status set to {new_status}.", "success")
            db.session.commit()
            return redirect(url_for("staff_trek_update", trek_id=trek.id))
        return render_template("staff_trek_update.html", trek=trek, statuses=TREK_STATUSES)

    @app.route("/staff/treks/<int:trek_id>/participants")
    @staff_active_required
    def staff_trek_participants(trek_id):
        trek = Trek.query.filter_by(id=trek_id, assigned_staff_id=current_user.id).first_or_404()
        bookings = Booking.query.filter_by(trek_id=trek.id).order_by(Booking.id.desc()).all()
        return render_template("staff_participants.html", trek=trek, bookings=bookings)

    # ---------------- Trekker (User) ----------------

    @app.route("/user/dashboard")
    @trekker_active_required
    def user_dashboard():
        open_treks = Trek.query.filter_by(status="Open").order_by(Trek.id.desc()).limit(5).all()
        my_bookings = Booking.query.filter_by(user_id=current_user.id).order_by(Booking.id.desc()).limit(5).all()
        return render_template("user_dashboard.html", open_treks=open_treks, my_bookings=my_bookings)

    @app.route("/user/treks")
    @trekker_active_required
    def user_treks():
        q = request.args.get("q", "").strip()
        difficulty = request.args.get("difficulty", "")
        location = request.args.get("location", "").strip()

        query = Trek.query.filter_by(status="Open")
        if q:
            like = f"%{q}%"
            query = query.filter(Trek.name.ilike(like))
        if difficulty:
            query = query.filter_by(difficulty=difficulty)
        if location:
            query = query.filter(Trek.location.ilike(f"%{location}%"))

        treks = query.order_by(Trek.start_date.asc()).all()

        my_trek_ids = {
            b.trek_id for b in Booking.query.filter_by(user_id=current_user.id, status="Booked").all()
        }
        return render_template(
            "user_treks.html", treks=treks, q=q, difficulty=difficulty, location=location,
            difficulties=DIFFICULTIES, my_trek_ids=my_trek_ids,
        )

    @app.route("/user/treks/<int:trek_id>/book", methods=["POST"])
    @trekker_active_required
    def user_book_trek(trek_id):
        trek = Trek.query.get_or_404(trek_id)

        if trek.status != "Open":
            flash("This trek is not open for booking.", "danger")
            return redirect(url_for("user_treks"))

        if trek.available_slots <= 0:
            flash("Sorry, this trek is fully booked.", "danger")
            return redirect(url_for("user_treks"))

        existing = Booking.query.filter_by(user_id=current_user.id, trek_id=trek.id, status="Booked").first()
        if existing:
            flash("You have already booked this trek.", "info")
            return redirect(url_for("user_treks"))

        booking = Booking(user_id=current_user.id, trek_id=trek.id, status="Booked")
        trek.available_slots -= 1
        db.session.add(booking)
        db.session.commit()
        flash(f"Trek '{trek.name}' booked successfully!", "success")
        return redirect(url_for("user_bookings"))

    @app.route("/user/bookings")
    @trekker_active_required
    def user_bookings():
        bookings = Booking.query.filter_by(user_id=current_user.id).order_by(Booking.id.desc()).all()
        return render_template("user_bookings.html", bookings=bookings)

    @app.route("/user/bookings/<int:booking_id>/cancel", methods=["POST"])
    @trekker_active_required
    def user_cancel_booking(booking_id):
        booking = Booking.query.filter_by(id=booking_id, user_id=current_user.id).first_or_404()
        if booking.status == "Booked":
            booking.status = "Cancelled"
            booking.trek.available_slots += 1
            db.session.commit()
            flash("Booking cancelled.", "info")
        return redirect(url_for("user_bookings"))

    @app.route("/user/profile", methods=["GET", "POST"])
    @trekker_active_required
    def user_profile():
        if request.method == "POST":
            current_user.name = request.form["name"].strip()
            current_user.contact = request.form.get("contact", "").strip()
            new_password = request.form.get("password", "")
            if new_password:
                current_user.set_password(new_password)
            db.session.commit()
            flash("Profile updated.", "success")
            return redirect(url_for("user_profile"))
        return render_template("user_profile.html")

    # ---------------- Error handlers ----------------

    @app.errorhandler(403)
    def forbidden(e):
        return render_template("error.html", code=403, message="You don't have permission to view this page."), 403

    @app.errorhandler(404)
    def not_found(e):
        return render_template("error.html", code=404, message="Page not found."), 404

    # Make some things available in every template
    @app.context_processor
    def inject_globals():
        return dict(current_year=date.today().year)


app = create_app()

if __name__ == "__main__":
    app.run(debug=True)
