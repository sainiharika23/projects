# Trekking Management Application

A Flask + Jinja2 + Bootstrap + SQLite web app implementing the Admin / Trek Staff / User (Trekker)
roles described in the App Dev I project statement (May 2026).

## Tech stack
- **Backend:** Flask, Flask-Login (session auth), Flask-SQLAlchemy (ORM over SQLite)
- **Frontend:** Jinja2 templates, Bootstrap 5 (via CDN), plain HTML forms — no JS required for
  core functionality
- **Database:** SQLite, created programmatically via `db.create_all()` in `app.py` (no manual
  DB Browser steps)

## Step-by-step: how to run it

### 1. Requirements
- Python 3.9+ installed
- (Recommended) a virtual environment

### 2. Unzip and enter the project folder
```bash
unzip trekking_app.zip
cd trekking_app
```

### 3. Create and activate a virtual environment
```bash
python3 -m venv venv

# macOS / Linux
source venv/bin/activate

# Windows
venv\Scripts\activate
```

### 4. Install dependencies
```bash
pip install -r requirements.txt
```

### 5. Run the app
```bash
python app.py
```
The first time it runs, it will automatically:
- Create `trekking.db` (SQLite file) in the project folder
- Create all tables (`users`, `treks`, `bookings`)
- Seed the pre-existing Admin account

You should see output like:
```
 * Running on http://127.0.0.1:5000
```

### 6. Open the app
Go to **http://127.0.0.1:5000** in your browser.

### 7. Log in
**Admin (pre-seeded, no registration needed):**
- Email: `admin@trek.com`
- Password: `admin123`

**Trek Staff / Trekker:** click "Register" on the login page. Trek Staff accounts require
admin approval (see below) before they can access their dashboard; Trekker accounts can log in
immediately.

## Suggested demo walkthrough

1. Log in as **Admin** → create a new trek (Admin dashboard → "+ New Trek").
2. Log out, **register** a new Trek Staff account → try logging in → you'll see the
   "Awaiting Admin Approval" screen.
3. Log back in as **Admin** → go to "Staff" → click **Approve** on the new staff member.
4. Still as Admin, go to "Treks" → use the dropdown next to the trek to **assign** the newly
   approved staff member (this moves the trek from `Pending` to `Approved`).
5. Log out, log in as the **Staff** member → "My Treks" → open the assigned trek → set its
   status to `Open` and set the slot count.
6. Log out, **register** a Trekker account (or log back in as one) → "Browse Treks" → search /
   filter by difficulty or location → **Book** the now-Open trek.
7. Check "My Bookings" to see status and cancel if desired (slots are automatically returned).
8. As Staff, open "Participants" on the trek to see who booked it.
9. As Admin, check "Bookings" to see every booking system-wide, and try **blacklisting** a user
   or staff member from the "Users"/"Staff" pages — a blacklisted account is blocked at login.

## Project structure
```
trekking_app/
├── app.py                  # All routes (auth, admin, staff, trekker) + app factory
├── models.py                # SQLAlchemy models: User, Trek, Booking
├── requirements.txt
├── trekking.db               # created automatically on first run (not in the zip)
├── static/
│   └── css/style.css
└── templates/
    ├── base.html, login.html, register.html, pending.html, error.html
    ├── admin_dashboard.html, admin_treks.html, admin_trek_form.html,
    │   admin_staff.html, admin_users.html, admin_bookings.html
    ├── staff_dashboard.html, staff_trek_update.html, staff_participants.html
    └── user_dashboard.html, user_treks.html, user_bookings.html, user_profile.html
```

## Data model (for your ER diagram)

**User** (`users`): id, name, email (unique), password_hash, contact, role
(admin/staff/trekker), approved (bool — staff-only gate), blacklisted (bool), created_at

**Trek** (`treks`): id, name, location, difficulty, duration_days, total_slots,
available_slots, description, assigned_staff_id (FK → users.id), status
(Pending/Approved/Open/Closed/Completed), start_date, end_date, created_at

**Booking** (`bookings`): id, user_id (FK → users.id), trek_id (FK → treks.id),
booking_date, status (Booked/Cancelled/Completed)

Relationships: one User(staff) → many Treks (assigned_staff_id); one User(trekker) → many
Bookings; one Trek → many Bookings (cascade delete).

## Core rules implemented
- Only an approved, non-blacklisted staff member can access `/staff/*` routes.
- Only the staff member assigned to a trek can update it or view its participants.
- A trekker can only book a trek whose status is `Open` and that still has `available_slots > 0`
  (enforced server-side — prevents overbooking even via manual URL access).
- Cancelling a booking returns the slot to the trek's available pool.
- Blacklisted users/staff are blocked at login.
- Admin dashboard shows live counts of treks, users, staff, and bookings.
- Search/filter is available for treks (name/location), staff (name/email), and users
  (name/email).

## Notes for your report
- This project deliberately keeps everything in a single `app.py` (no blueprints) and a single
  `models.py` so the code is easy to read end-to-end for the viva — feel free to refactor into
  blueprints if you prefer a larger-project structure.
- Passwords are hashed with Werkzeug's `generate_password_hash` (never stored in plaintext).
- Change `app.config["SECRET_KEY"]` and the seeded admin password before any real deployment.
